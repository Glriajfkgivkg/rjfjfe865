/* eslint-disable @typescript-eslint/no-explicit-any */

declare module "*.svg" {
  const value: any;
  export = value;
}

declare module "*.jpg" {
  const value: any;
  export = value;
}

declare module "*.jfif" {
  const value: any;
  export = value;
}

declare module "*.pjp" {
  const value: any;
  export = value;
}

declare module "*.png" {
  const value: any;
  export = value;
}

declare module "*.webp" {
  const value: any;
  export = value;
}

declare module "*.gif" {
  const value: any;
  export = value;
}

declare module "*.jpeg" {
  const value: any;
  export = value;
}

declare module "*.pjpeg" {
  const value: any;
  export = value;
}

