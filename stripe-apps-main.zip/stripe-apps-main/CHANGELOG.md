View the changelog on NPM: https://www.npmjs.com/package/@stripe/ui-extension-sdk
