# Stripe Apps manifest JSON schema

This package stores and tests the JSON schema for the `stripe-app.json` manifest file. It will be referenced in the [JSON Schema Store](https://schemastore.org) catalog.
