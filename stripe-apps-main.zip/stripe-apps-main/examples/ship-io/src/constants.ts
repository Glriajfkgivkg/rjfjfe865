export const TITLE = "Ship.IO";
export const BRAND_COLOR = "#00356b";
