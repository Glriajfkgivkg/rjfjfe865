Before starting, make sure you:

1. Create a `.env` file based on the contents of `.env.example` with correct values.
2. Run `yarn generateKeys` to create `server.key` and `server.cert` files.